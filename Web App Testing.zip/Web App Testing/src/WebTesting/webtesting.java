package WebTesting;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

public class webtesting extends capabilities {

	AndroidDriver<AndroidElement> driver;
	
	@BeforeTest
	public void setup() throws MalformedURLException
	{
		//i am calling that method from capabilities class and this executes before any test.
		driver = capability();
		//implicitly wait
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
	} 
	
	@Test
	public void testcase1()
	{
		System.out.println("The browser should open");
		//let me also open an url
		driver.get("http://www.google.com");
		//i want to search for ibm in google
		driver.findElement(By.xpath("//*[@name='q']")).sendKeys("IBM");
		driver.findElement(By.xpath("//*[@name='q']")).sendKeys(Keys.ENTER);
		//i want to scroll and click on ibm wikipedia
		//webdriver/javascript
		JavascriptExecutor js = (JavascriptExecutor)driver;
		//i am storing the element properties that i want to click
		WebElement link = driver.findElement(By.xpath("//*[contains(text(),'IBM-Wikipedia')]"));
		//this will help you to scroll to the link to be clicked
		js.executeScript("argument[0].scrollIntoview(false);",link);
		//this will click the element
		link.click();
	}
}
