package WebTesting;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.appium.java_client.remote.AutomationName;
import io.appium.java_client.remote.MobileCapabilityType;

public class capabilities {

	public static AndroidDriver<AndroidElement> capability() throws MalformedURLException {
		//i want to check if my emulator has this capability if it has i can run my test
		DesiredCapabilities cap = new DesiredCapabilities();
		// there are few capabilities which are common for web, native, hybrid
		//common all the time
		cap.setCapability(MobileCapabilityType.DEVICE_NAME, "Lavanya Android");
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		//this capability is optional for android and mandatory for ios
		cap.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.ANDROID_UIAUTOMATOR2);
		//this is mandatory if your testing ios
		//cap.setCapability(MobileCapabilityType.AUTOMATION_NAME, AutomationName.IOS_XCUI_TEST);
		//what kind of testing ur doing
		//Since i am doing webapp testing i need browser
		cap.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
		//i have a capability which is inside android
		cap.setCapability(AndroidMobileCapabilityType.CHROMEDRIVER_EXECUTABLE,"C:\\ChromeDriver\\Chrome90\\chromedriver_win32 (1)\\chromedriver.exe");
		//WbeDriver driver = new ChromeDriver();
		AndroidDriver<AndroidElement> driver = new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"),cap);
		return driver;
		//i dont want to wirte this capability everytime, i would like to call this as a function
	}

}
 