package Hybrid;

import static io.appium.java_client.touch.LongPressOptions.longPressOptions;
import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static java.time.Duration.ofSeconds;

import java.net.MalformedURLException;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.Assert;
//import com.sun.tools.javac.util.Assert;

import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;

import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.TapOptions;
import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static io.appium.java_client.touch.LongPressOptions.longPressOptions;
import static java.time.Duration.ofSeconds;

public class HybridTesting extends Capability {
AndroidDriver<AndroidElement> driver;
	
	@BeforeTest
	public void setup() throws MalformedURLException
	{
		driver = Capabilities();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				
	} 
	
	@Test(enabled=false)
	public void testcase1()
	{
		driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Lavanya");
		  driver.findElement(By.xpath("//*[@text='Female']")).click();
	        driver.findElement(By.id("android:id/text1")).click();
	        driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Australia\"))").click();
	        driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();
	}
	
	@Test(enabled=false)
	public void testcase2()
	{
		//driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Lavanya");
		  driver.findElement(By.xpath("//*[@text='Female']")).click();
	        driver.findElement(By.id("android:id/text1")).click();
	        driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Australia\"))").click();
	        driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();
	        //i want to capture the error message and apply assert on the text of error message
	        //toast is used to capture the error message
	        String errmsg = driver.findElement(By.xpath("//android.widget.Toast[1]")).getAttribute("name");
	        String actmsg = "Please enter your name";
	        Assert.assertEquals(actmsg, errmsg);
	        //org.testng.Assert.assertEquals(actmsg, errmsg)
	}
	
	@Test(enabled=false)
	public void testcase3() throws InterruptedException
	{
		driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Lavanya");
		  driver.findElement(By.xpath("//*[@text='Female']")).click();
	        driver.findElement(By.id("android:id/text1")).click();
	        driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Australia\"))").click();
	        driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();
	        //this will click on the first add to cart button
	        driver.findElements(By.xpath("//*[@text='ADD TO CART']")).get(0).click();
	        driver.findElements(By.xpath("//*[@text='ADD TO CART']")).get(0).click();
	        driver.findElement(By.id("com.androidsample.generalstore:id/appbar_btn_cart")).click();
	        Thread.sleep(5000);
	        String  amount1 = driver.findElements(By.id("com.androidsample.generalstore:id/productPrice")).get(0).getText();
	         String  amount2 = driver.findElements(By.id("com.androidsample.generalstore:id/productPrice")).get(1).getText();
	         //this line is for remove the $ sysmbol
	         amount1 = amount1.substring(1);
	         //this line is basically for converting my string in to dobule 
	        Double amount1value = Double.parseDouble(amount1);
	        
	        amount2 = amount2.substring(1);
	        Double amount2value = Double.parseDouble(amount2);
	        //in this line i am adding both the value 
	        Double total = amount1value +amount2value;
	       // System.out.println(total);
	        
	        //i am Taking the total cost of the two products
	        String finalvalue = driver.findElement(By.id("com.androidsample.generalstore:id/totalAmountLbl")).getText();
	        //i am removing the $ sysmbol
	        finalvalue = finalvalue.substring(1);
	        //i am converting from striong to double
	        Double finaltotalvalue = Double.parseDouble(finalvalue);
	        //here i am asserting to check both are same value
	        
	        Assert.assertEquals(finaltotalvalue, total);
	        
	        
	        
	        
	}
	@Test(enabled=true)
	public void testcase4() throws InterruptedException
	{
		driver.findElement(By.id("com.androidsample.generalstore:id/nameField")).sendKeys("Lavanya");
		  driver.findElement(By.xpath("//*[@text='Female']")).click();
	        driver.findElement(By.id("android:id/text1")).click();
	        driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Australia\"))").click();
	        driver.findElement(By.id("com.androidsample.generalstore:id/btnLetsShop")).click();
	        /*driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"Nike Blazer Mid '77\"));");
	        WebElement add = driver.findElements(By.xpath("//*[@text='ADD TO CART']")).get(0);
	        add.click();*/
	        //here i am scrolling till product name
	        driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector().resourceId(\"com.androidsample.generalstore:id/rvProductList\")).scrollIntoView(textMatches(\"Jordan 6 Rings\").instance(0))");
	        //after scrolling and finding my prodcut i want to add to cart
	        int count = driver.findElements(By.id("com.androidsample.generalstore:id/productName")).size();
	        for(int i=0;i<count;i++)
	        {
	            String Name = driver.findElements(By.id("com.androidsample.generalstore:id/productName")).get(i).getText();
	            if(Name.equals("Jordan 6 Rings"))
	            {
	                driver.findElements(By.id("com.androidsample.generalstore:id/productAddCart")).get(i).click();
	                break;
	            }
	            //this line adds to cart
	            driver.findElement(By.id("com.androidsample.generalstore:id/appbar_btn_cart")).click();
	           
	            //tap, longpress and 
	           /* TouchAction t = new TouchAction(driver);
	        	WebElement checkbox = driver.findElement(By.className("android.widget.CheckBox"));
	        	t.tap(tapOptions().withElement(element(checkbox))).perform();
	        	t.longPress(longPressOptions().withElement(element(checkbox)).withDuration(ofSeconds(3))).release().perform();*/
	            TouchAction t = new TouchAction(driver);
	            WebElement EL = driver.findElement(By.className("android.widget.CheckBox"));
	              t.tap(tapOptions().withElement(element(EL))).perform();
	              WebElement TC = driver.findElement(By.xpath("//*[@text='Please read our terms of conditions']"));
	              t.longPress(longPressOptions().withElement(element(TC)).withDuration(ofSeconds(3))).release().perform();
	              driver.findElement(By.id("android:id/button1")).click();
	              driver.findElement(By.xpath("//*[@text='Visit to the website to complete purchase']")).click();
	              Thread.sleep(9000);
	              //whenever u want to know what context are there in hybrid app you can use context
	              Set<String> contextNames = driver.getContextHandles();
	              for (String contextName : contextNames) {
	                  System.out.println(contextName); //prints out something like NATIVE_APP \n WEBVIEW_1
	              }
	              driver.context("WEBVIEW_com.androidsample.generalstore");
	              driver.findElement(By.xpath("//*[@name='q']")).sendKeys("IBM");
	              driver.findElement(By.xpath("//*[@name='q']")).sendKeys(Keys.ENTER);
	            //these 2 lines will help to move back to native app
	              driver.pressKey(new KeyEvent(AndroidKey.BACK));
	              driver.context("NATIVE_APP");
	        }
	}
	

	
}
