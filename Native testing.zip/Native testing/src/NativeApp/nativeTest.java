package NativeApp;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.TapOptions;
import static io.appium.java_client.touch.TapOptions.tapOptions;
import static io.appium.java_client.touch.offset.ElementOption.element;
import static io.appium.java_client.touch.LongPressOptions.longPressOptions;
import static java.time.Duration.ofSeconds;



public class nativeTest extends capability{

AndroidDriver<AndroidElement> driver;
    
    @BeforeTest
    public void setup() throws MalformedURLException
    {
        driver = capabilities();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }
    
    @Test(enabled=true)
    public void testcase1() throws InterruptedException
    {
        //System.out.println("working");
    	driver.findElementByAccessibilityId("Preference").click();
    	//driver.findElement(MobileBy.AccessibilityId("Preference")).click();
    	driver.findElementByAccessibilityId("3. Preference dependencies").click();
    	driver.findElement(By.id("android:id/checkbox")).click();
    	driver.findElement(MobileBy.AndroidUIAutomator("UiSelector().text(\"WiFi settings\")")).click();
    	driver.findElement(MobileBy.AndroidUIAutomator("UiSelector().text(\"WiFi settings\")")).click();
        //what is my next //i enter some data
        driver.findElement(By.id("android:id/edit")).sendKeys("Aaditya & Aradhya");
        //for sure the keypad will open //close the key board we use hide keyboard
        driver.hideKeyboard();
        //this will find the index of 0
        WebElement cancelbtn = driver.findElements(By.className("android.widget.Button")).get(0);
        cancelbtn.click();
        //i want to navigate back to first page
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        Thread.sleep(3000);
        driver.pressKey(new KeyEvent(AndroidKey.BACK));
        
    }
    @Test(enabled = false)
    public void testcase2(){
    	driver.findElementByAccessibilityId("Views").click();
    	//it is similar to click // tap is called as a gesture in mobile teting
    	//for tapping an element
    	TouchAction t = new TouchAction(driver);
    	//the element which i wanted to tap i stored it in a webelement
    	WebElement EL = driver.findElementByAccessibilityId("Expandable Lists");
    	t.tap(tapOptions().withElement(element(EL))).perform();
    	driver.findElementByAccessibilityId("1. Custom Adapter").click();
    	//i want to do a long press - can hold long press for 3 seconds
    	WebElement LP = driver.findElement(By.xpath("//*[@text='People Names']"));
    	t.longPress(longPressOptions().withElement(element(LP)).withDuration(ofSeconds(3))).release().perform();
    	//driver.findElement(By.xpath("//*[@text='Sample action']"));	
    	// want to click on sample action using index
    	String sampleoption = driver.findElements(By.className("android.widget.TextView")).get(1).getText();
    	System.out.println(sampleoption);
    	}
    
    @Test(enabled = false)
    public void testcase3() {
    	driver.findElementByAccessibilityId("Views").click();
    	//if i want to scroll till the end what will i use
    	driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView(text(\"WebView\"));").click();
    	}
    
    
    //this is how you click with notifications
    @Test(enabled=false)
    public void testcase4() {
    	//method to open a notification
    	driver.openNotifications();
    	//click on battery saver
    	driver.findElementByAccessibilityId("Battery Saver").click();
    	}
    
    //swipe action
    @Test(enabled=false)
    public void testcase5() {
    	driver.findElementByAccessibilityId("Views").click();
    	driver.findElementByAccessibilityId("Date Widgets").click();
    	driver.findElementByAccessibilityId("2. Inline").click();
    	driver.findElementByAccessibilityId("9").click();
    	//i want to swipe from 15 to 45
    	WebElement btn1 = driver.findElementByAccessibilityId("15");
    	WebElement btn2 = driver.findElementByAccessibilityId("45");
    	TouchAction t = new TouchAction(driver);
    	t.longPress(longPressOptions().withElement(element(btn1)).withDuration(ofSeconds(2))).moveTo(element(btn2)).release().perform();
    	}
	
    //1. click on views
    //2. click on drag and drop
    //3. drag the element 1 to element 2
    @Test(enabled=true)
    public void testcase6() {
    	driver.findElementByAccessibilityId("Views").click();
    	driver.findElementByAccessibilityId("Drag and Drop").click();
       	driver.findElement(By.id("io.appium.android.apis:id/drag_dot_1")).click();
       	WebElement dot1 = driver.findElement(By.id("io.appium.android.apis:id/drag_dot_1"));
    	WebElement dot2 = driver.findElement(By.id("io.appium.android.apis:id/drag_dot_2"));
    	TouchAction drag = new TouchAction(driver);
    	drag.longPress(longPressOptions().withElement(element(dot1)).withDuration(ofSeconds(2))).moveTo(element(dot2)).release().perform();
     	}
    
}
